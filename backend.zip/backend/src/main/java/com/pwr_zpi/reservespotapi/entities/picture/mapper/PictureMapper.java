package com.pwr_zpi.reservespotapi.entities.picture.mapper;

import com.pwr_zpi.reservespotapi.entities.picture.dto.CreatePictureDto;
import com.pwr_zpi.reservespotapi.entities.picture.dto.PictureDto;
import com.pwr_zpi.reservespotapi.entities.picture.dto.UpdatePictureDto;
import com.pwr_zpi.reservespotapi.entities.picture.Picture;
import com.pwr_zpi.reservespotapi.entities.restaurant.Restaurant;
import com.pwr_zpi.reservespotapi.entities.review.Review;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
public class PictureMapper {

    public PictureDto toDto(Picture picture) {
        if (picture == null) {
            return null;
        }

        return PictureDto.builder()
                .id(picture.getId())
                .url(picture.getUrl())
                .uploadedAt(picture.getUploadedAt())
                .description(picture.getDescription())
                .restaurantIds(picture.getRestaurants() != null ? 
                    picture.getRestaurants().stream().map(Restaurant::getId).collect(Collectors.toSet()) : null)
                .reviewIds(picture.getReviews() != null ? 
                    picture.getReviews().stream().map(Review::getId).collect(Collectors.toSet()) : null)
                .build();
    }

    public Picture toEntity(CreatePictureDto dto) {
        if (dto == null) {
            return null;
        }

        return Picture.builder()
                .url(dto.getUrl())
                .description(dto.getDescription())
                .uploadedAt(java.time.LocalDateTime.now())
                .build();
    }

    public void updateEntity(UpdatePictureDto dto, Picture picture) {
        if (dto == null || picture == null) {
            return;
        }

        if (dto.getUrl() != null) {
            picture.setUrl(dto.getUrl());
        }
        if (dto.getDescription() != null) {
            picture.setDescription(dto.getDescription());
        }
    }
}
